package hu.sajatmagyartolmacs

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.RecognitionListener
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import android.graphics.Color
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentifier
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var inputText: TextView
    private lateinit var translatedText: TextView
    private lateinit var directionPicker: Spinner
    private lateinit var autoDetectCheck: CheckBox
    private var languageIdentifier: LanguageIdentifier? = null
    private lateinit var typedInput: EditText
    private lateinit var historyBox: LinearLayout
    private lateinit var continuousButton: Button
    private lateinit var prefs: SharedPreferences
    private var tts: TextToSpeech? = null
    private var translator: Translator? = null
    private var ttsReady = false
    private var direction = 0 // 0: German -> Hungarian, 1: Hungarian -> German
    private var lastTranslation = ""
    private var isTranslating = false
    private var continuousMode = false
    private var speechRecognizer: SpeechRecognizer? = null
    private val speechHandler = Handler(Looper.getMainLooper())

    companion object {
        private const val SPEECH_REQUEST = 4101
        private const val MIC_REQUEST = 4102
        private const val HISTORY_KEY = "translation_history"
        private const val MAX_HISTORY = 30
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("tolmacs", MODE_PRIVATE)
        direction = prefs.getInt("translation_direction", 0).coerceIn(0, 1)
        tts = TextToSpeech(this, this)
        showHome()
        renderHistory()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), MIC_REQUEST)
        }
    }

    private fun showHome() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 22)
            setBackgroundColor(Color.rgb(246, 249, 248))
        }
        scroll.addView(root)
        root.addView(TextView(this).apply {
            text = "Saját Magyar Tolmács"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(16, 63, 56))
            setPadding(0, 4, 0, 4)
        }, lp())
        root.addView(TextView(this).apply {
            text = "Német  ⇄  Magyar"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
        }, lp())

        directionPicker = Spinner(this)
        directionPicker.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Német → magyar", "Magyar → német"))
        directionPicker.setSelection(direction, false)
        directionPicker.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (direction != position) {
                    if (continuousMode) stopContinuousMode()
                    direction = position
                    prefs.edit().putInt("translation_direction", direction).apply()
                    closeTranslator()
                    translatedText.text = "A fordítás itt jelenik meg."
                    lastTranslation = ""
                    status.text = "Irány megváltoztatva."
                }
            }
        }
        root.addView(directionPicker, lp())

        autoDetectCheck = CheckBox(this).apply {
            text = "A beírt/felismert szöveg nyelvének automatikus felismerése"
            isChecked = prefs.getBoolean("auto_detect_language", true)
            setTextColor(Color.DKGRAY)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("auto_detect_language", checked).apply()
                status.text = if (checked) "Automatikus nyelvfelismerés bekapcsolva." else "Kézi fordítási irány használata."
            }
        }
        root.addView(autoDetectCheck, lp())

        status = TextView(this).apply {
            text = "Készen áll. Írhatsz vagy beszélhetsz."
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(38, 94, 82))
            setPadding(4, 8, 4, 8)
        }
        root.addView(status, lp())

        root.addView(Button(this).apply {
            text = "🎙  BESZÉLJ MOST"
            textSize = 17f
            setOnClickListener { listen() }
        }, lp())
        continuousButton = Button(this).apply {
            text = "🔁  FOLYAMATOS BESZÉLGETÉS INDÍTÁSA"
            setOnClickListener {
                if (continuousMode) stopContinuousMode() else startContinuousMode()
            }
        }
        root.addView(continuousButton, lp())

        root.addView(TextView(this).apply {
            text = "VAGY ÍRD BE A SZÖVEGET"
            textSize = 12f
            setTextColor(Color.DKGRAY)
        }, lp())
        typedInput = EditText(this).apply {
            hint = "Ide írd a német vagy magyar szöveget…"
            textSize = 16f
            minLines = 2
            gravity = Gravity.TOP
            setPadding(14, 12, 14, 12)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(typedInput, lp())
        root.addView(Button(this).apply {
            text = "SZÖVEG LEFORDÍTÁSA"
            setOnClickListener {
                val value = typedInput.text?.toString()?.trim().orEmpty()
                if (value.isBlank()) status.text = "Előbb írj be egy szöveget."
                else {
                    inputText.text = value
                    translate(value)
                }
            }
        }, lp())
        root.addView(Button(this).apply {
            text = "⬇ MINDKÉT NYELVI MODELL LETÖLTÉSE OFFLINE HASZNÁLATHOZ"
            setOnClickListener { downloadBothModels() }
        }, lp())

        root.addView(TextView(this).apply {
            text = "FELISMERT / BEÍRT SZÖVEG"
            textSize = 12f
            setTextColor(Color.DKGRAY)
        }, lp())
        inputText = TextView(this).apply {
            text = "A felismert vagy beírt szöveg itt jelenik meg."
            textSize = 17f
            setTextColor(Color.BLACK)
            setPadding(16, 16, 16, 16)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(inputText, lp())

        root.addView(TextView(this).apply {
            text = "FORDÍTÁS"
            textSize = 12f
            setTextColor(Color.DKGRAY)
        }, lp())
        translatedText = TextView(this).apply {
            text = "A fordítás itt jelenik meg."
            textSize = 19f
            setTextColor(Color.rgb(16, 63, 56))
            setPadding(16, 18, 16, 18)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(translatedText, lp())

        root.addView(Button(this).apply {
            text = "🔊  FORDÍTÁS FELOLVASÁSA"
            setOnClickListener { speakTranslation() }
        }, lp())
        root.addView(Button(this).apply {
            text = "⇄  IRÁNY MEGFORDÍTÁSA"
            setOnClickListener { directionPicker.setSelection(1 - direction) }
        }, lp())

        root.addView(TextView(this).apply {
            text = "ELŐZMÉNYEK"
            textSize = 14f
            setTextColor(Color.rgb(16, 63, 56))
            setPadding(0, 14, 0, 4)
        }, lp())
        historyBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(historyBox, lp())
        root.addView(Button(this).apply {
            text = "ELŐZMÉNYEK TÖRLÉSE"
            setOnClickListener {
                prefs.edit().remove(HISTORY_KEY).apply()
                renderHistory()
                status.text = "Az előzmények törölve."
            }
        }, lp())

        root.addView(TextView(this).apply {
            text = "Megjegyzés: az első fordításhoz internet és a nyelvi modellek letöltése szükséges. A letöltött modellekkel a szövegfordítás offline is működhet. A beszédfelismerés offline elérhetősége a telefon szolgáltatásától függ. A hang a telefon aktuális hangkimenetén szólal meg (például csatlakoztatott fülhallgatón)."
            textSize = 12f
            setTextColor(Color.DKGRAY)
            setPadding(0, 12, 0, 10)
        }, lp())
        setContentView(scroll)
    }

    private fun lp() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        setMargins(0, 5, 0, 5)
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), MIC_REQUEST)
            status.text = "A mikrofonengedély szükséges."
            return
        }
        val inputLocale = if (direction == 0) "de-DE" else "hu-HU"
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, inputLocale)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, inputLocale)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_PROMPT, if (direction == 0) "Beszélj németül…" else "Beszélj magyarul…")
        }
        try {
            startActivityForResult(intent, SPEECH_REQUEST)
        } catch (_: Exception) {
            status.text = "Nem található beszédfelismerő alkalmazás ezen a telefonon."
        }
    }

    // Folyamatos, váltott megszólalásos mód: minden felismert mondat után
    // lefordít, majd újraindítja a mikrofonfigyelést. Nem valódi teljes duplex tolmács.
    private fun startContinuousMode() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), MIC_REQUEST)
            status.text = "A folyamatos módhoz mikrofonengedély szükséges."
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Ezen a telefonon nem érhető el beszédfelismerő szolgáltatás."
            return
        }
        try {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer ->
                recognizer.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        if (continuousMode) status.text = "Figyelek… Beszélj a kiválasztott nyelven."
                    }
                    override fun onBeginningOfSpeech() { }
                    override fun onRmsChanged(rmsdB: Float) { }
                    override fun onBufferReceived(buffer: ByteArray?) { }
                    override fun onEndOfSpeech() { }
                    override fun onError(error: Int) {
                        if (!continuousMode) return
                        if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ||
                            error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ||
                            error == SpeechRecognizer.ERROR_CLIENT) {
                            status.text = "A folyamatos beszédfelismerés leállt (hiba: $error)."
                            stopContinuousMode()
                        } else {
                            status.text = "Nem hallottam tisztán. Újra figyelek…"
                            scheduleContinuousListening(700)
                        }
                    }
                    override fun onResults(results: Bundle?) {
                        if (!continuousMode) return
                        val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                        if (words.isBlank()) {
                            scheduleContinuousListening(500)
                            return
                        }
                        inputText.text = words
                        typedInput.setText(words)
                        translate(words)
                    }
                    override fun onPartialResults(partialResults: Bundle?) { }
                    override fun onEvent(eventType: Int, params: Bundle?) { }
                })
            }
            continuousMode = true
            if (::continuousButton.isInitialized) continuousButton.text = "■  FOLYAMATOS BESZÉLGETÉS LEÁLLÍTÁSA"
            status.text = "Folyamatos mód elindult."
            scheduleContinuousListening(150)
        } catch (error: Exception) {
            stopContinuousMode()
            status.text = "Nem sikerült elindítani a folyamatos módot: ${error.localizedMessage ?: "hiba"}"
        }
    }

    private fun scheduleContinuousListening(delayMs: Long) {
        speechHandler.removeCallbacksAndMessages(null)
        speechHandler.postDelayed({
            if (!continuousMode || isTranslating) return@postDelayed
            val inputLocale = if (direction == 0) "de-DE" else "hu-HU"
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, inputLocale)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, inputLocale)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            try {
                speechRecognizer?.startListening(intent)
            } catch (_: Exception) {
                status.text = "A mikrofon újraindítása nem sikerült."
                stopContinuousMode()
            }
        }, delayMs)
    }

    private fun stopContinuousMode() {
        continuousMode = false
        if (::continuousButton.isInitialized) continuousButton.text = "🔁  FOLYAMATOS BESZÉLGETÉS INDÍTÁSA"
        speechHandler.removeCallbacksAndMessages(null)
        try { speechRecognizer?.cancel() } catch (_: Exception) { }
        try { speechRecognizer?.destroy() } catch (_: Exception) { }
        speechRecognizer = null
        if (::status.isInitialized) status.text = "Folyamatos mód leállítva."
    }

    @Deprecated("Android speech recognition result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == SPEECH_REQUEST) {
            if (resultCode == RESULT_OK) {
                val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
                if (words.isBlank()) {
                    status.text = "Nem sikerült felismerni a beszédet. Próbáld újra."
                    return
                }
                inputText.text = words
                typedInput.setText(words)
                translate(words)
            } else {
                status.text = "A beszédfelismerés megszakadt."
            }
        }
    }


    // Mindkét irány modelljét letölti, így később internet nélkül is lehessen
    // németből magyarra és magyarból németre fordítani.
    private fun downloadBothModels() {
        if (isTranslating) {
            status.text = "Egy másik művelet még folyamatban van. Várj egy pillanatot."
            return
        }
        isTranslating = true
        status.text = "1/2: Német–magyar nyelvi modell letöltése… Internetkapcsolat szükséges."

        val germanToHungarian = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.GERMAN)
                .setTargetLanguage(TranslateLanguage.HUNGARIAN)
                .build()
        )
        val hungarianToGerman = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.HUNGARIAN)
                .setTargetLanguage(TranslateLanguage.GERMAN)
                .build()
        )
        val conditions = DownloadConditions.Builder().build()

        germanToHungarian.downloadModelIfNeeded(conditions)
            .addOnSuccessListener {
                status.text = "2/2: Magyar–német nyelvi modell letöltése…"
                hungarianToGerman.downloadModelIfNeeded(conditions)
                    .addOnSuccessListener {
                        isTranslating = false
                        germanToHungarian.close()
                        hungarianToGerman.close()
                        status.text = "Mindkét fordítási modell letöltése kész. A szövegfordítás mindkét irányban offline is működhet."
                    }
                    .addOnFailureListener { error ->
                        isTranslating = false
                        germanToHungarian.close()
                        hungarianToGerman.close()
                        status.text = "A német–magyar modell kész, de a magyar–német letöltése nem sikerült: ${error.localizedMessage ?: "ellenőrizd az internetkapcsolatot"}"
                    }
            }
            .addOnFailureListener { error ->
                isTranslating = false
                germanToHungarian.close()
                hungarianToGerman.close()
                status.text = "A német–magyar modell letöltése nem sikerült: ${error.localizedMessage ?: "ellenőrizd az internetkapcsolatot"}"
            }
    }

    private fun downloadCurrentModel() {
        if (isTranslating) {
            status.text = "A fordítás még folyamatban van. Várj egy pillanatot."
            return
        }
        isTranslating = true
        status.text = "A kiválasztott nyelvi modell letöltése… Ehhez internetkapcsolat kell."
        val source = if (direction == 0) TranslateLanguage.GERMAN else TranslateLanguage.HUNGARIAN
        val target = if (direction == 0) TranslateLanguage.HUNGARIAN else TranslateLanguage.GERMAN
        if (translator == null) {
            val options = TranslatorOptions.Builder().setSourceLanguage(source).setTargetLanguage(target).build()
            translator = Translation.getClient(options)
        }
        val currentTranslator = translator
        if (currentTranslator == null) {
            isTranslating = false
            status.text = "A fordító nem indítható el."
            return
        }
        currentTranslator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                isTranslating = false
                status.text = "A nyelvi modell letöltése kész. Ezzel az iránnyal a szövegfordítás internet nélkül is működhet."
            }
            .addOnFailureListener { error ->
                isTranslating = false
                status.text = "A modell letöltése nem sikerült: ${error.localizedMessage ?: "ellenőrizd az internetkapcsolatot"}"
            }
    }

    private fun translate(text: String) {
        if (isTranslating) return
        val detectAutomatically = ::autoDetectCheck.isInitialized && autoDetectCheck.isChecked
        if (!detectAutomatically) {
            translateUsingSelectedDirection(text)
            return
        }

        isTranslating = true
        status.text = "A szöveg nyelvének felismerése…"
        val identifier = languageIdentifier ?: LanguageIdentification.getClient().also { languageIdentifier = it }
        identifier.identifyLanguage(text)
            .addOnSuccessListener { languageCode ->
                if (languageCode == "de" || languageCode == "hu") {
                    val detectedDirection = if (languageCode == "de") 0 else 1
                    if (direction != detectedDirection) {
                        direction = detectedDirection
                        prefs.edit().putInt("translation_direction", direction).apply()
                        if (::directionPicker.isInitialized) directionPicker.setSelection(direction)
                        closeTranslator()
                    }
                    status.text = if (languageCode == "de") "Német nyelv felismerve. Fordítás magyarra…" else "Magyar nyelv felismerve. Fordítás németre…"
                } else {
                    status.text = "A nyelv nem azonosítható biztosan; a kiválasztott irányt használom."
                }
                isTranslating = false
                translateUsingSelectedDirection(text)
            }
            .addOnFailureListener {
                // Ha a nyelvfelismerő nem érhető el, a felhasználó által kiválasztott iránnyal folytatjuk.
                isTranslating = false
                status.text = "A nyelvfelismerés nem sikerült; a kiválasztott irányt használom."
                translateUsingSelectedDirection(text)
            }
    }

    private fun translateUsingSelectedDirection(text: String) {
        if (isTranslating) return
        isTranslating = true
        status.text = "Fordító és nyelvi modell előkészítése…"
        val source = if (direction == 0) TranslateLanguage.GERMAN else TranslateLanguage.HUNGARIAN
        val target = if (direction == 0) TranslateLanguage.HUNGARIAN else TranslateLanguage.GERMAN
        if (translator == null) {
            val options = TranslatorOptions.Builder().setSourceLanguage(source).setTargetLanguage(target).build()
            translator = Translation.getClient(options)
        }
        val currentTranslator = translator
        if (currentTranslator == null) {
            isTranslating = false
            status.text = "A fordító nem indítható el."
            return
        }
        currentTranslator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                status.text = "Fordítás…"
                currentTranslator.translate(text)
                    .addOnSuccessListener { result ->
                        isTranslating = false
                        lastTranslation = result
                        translatedText.text = result
                        status.text = "Fordítás kész."
                        addHistory(text, result)
                        speakTranslation()
                    }
                    .addOnFailureListener { error ->
                        isTranslating = false
                        status.text = "A fordítás nem sikerült: ${error.localizedMessage ?: "ismeretlen hiba"}"
                        if (continuousMode) scheduleContinuousListening(900)
                    }
            }
            .addOnFailureListener { error ->
                isTranslating = false
                status.text = "A nyelvi modell letöltése nem sikerült. Ellenőrizd az internetet. (${error.localizedMessage ?: "hiba"})"
                if (continuousMode) scheduleContinuousListening(1200)
            }
    }

    private fun speakTranslation() {
        val text = lastTranslation.ifBlank { translatedText.text?.toString().orEmpty() }
        if (text.isBlank() || text == "A fordítás itt jelenik meg.") {
            status.text = "Még nincs felolvasható fordítás."
            return
        }
        val engine = tts
        if (!ttsReady || engine == null) {
            status.text = "A telefon beszédhangja még töltődik."
            if (continuousMode) scheduleContinuousListening(1200)
            return
        }
        val locale = if (direction == 0) Locale("hu", "HU") else Locale.GERMAN
        if (engine.isLanguageAvailable(locale) < TextToSpeech.LANG_AVAILABLE) {
            status.text = "A kívánt felolvasó hang nincs telepítve a telefonon."
            return
        }
        engine.language = locale
        val result = engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "translation_output")
        if (result == TextToSpeech.ERROR && continuousMode) {
            status.text = "A felolvasás nem indult el; újra figyelek."
            scheduleContinuousListening(900)
        }
    }

    private fun addHistory(source: String, target: String) {
        val stamp = SimpleDateFormat("yyyy.MM.dd HH:mm", Locale.getDefault()).format(Date())
        val old = prefs.getString(HISTORY_KEY, "").orEmpty().lines().filter { it.isNotBlank() }
        val entry = "$stamp\t${if (direction == 0) "DE→HU" else "HU→DE"}\t${source.replace('\n', ' ').replace('\t', ' ')}\t${target.replace('\n', ' ').replace('\t', ' ')}"
        val updated = (listOf(entry) + old).take(MAX_HISTORY)
        prefs.edit().putString(HISTORY_KEY, updated.joinToString("\n")).apply()
        renderHistory()
    }

    private fun renderHistory() {
        if (!::historyBox.isInitialized) return
        historyBox.removeAllViews()
        val entries = prefs.getString(HISTORY_KEY, "").orEmpty().lines().filter { it.isNotBlank() }
        if (entries.isEmpty()) {
            historyBox.addView(TextView(this).apply {
                text = "Még nincs mentett beszélgetés."
                textSize = 13f
                setTextColor(Color.GRAY)
            }, lp())
            return
        }
        entries.forEach { entry ->
            val parts = entry.split('\t', limit = 4)
            val view = TextView(this).apply {
                text = if (parts.size == 4) "${parts[0]}  •  ${parts[1]}\n${parts[2]}\n➜ ${parts[3]}" else entry
                textSize = 13f
                setTextColor(Color.DKGRAY)
                setPadding(12, 10, 12, 10)
                setBackgroundColor(Color.WHITE)
            }
            historyBox.addView(view, lp())
        }
    }

    private fun closeTranslator() {
        translator?.close()
        translator = null
    }

    override fun onInit(result: Int) {
        ttsReady = result == TextToSpeech.SUCCESS
        val engine = tts
        if (ttsReady && engine != null) {
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) { }
                override fun onDone(utteranceId: String?) {
                    // Csak a felolvasás befejezése után nyissuk újra a mikrofont,
                    // különben a telefon saját hangját is visszahallhatja.
                    if (utteranceId == "translation_output") {
                        speechHandler.post {
                            if (continuousMode) scheduleContinuousListening(350)
                        }
                    }
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    if (utteranceId == "translation_output") {
                        speechHandler.post {
                            if (continuousMode) scheduleContinuousListening(700)
                        }
                    }
                }
            })
        }
        if (!ttsReady && ::status.isInitialized) status.text = "A telefon felolvasó szolgáltatása nem indult el."
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == MIC_REQUEST && ::status.isInitialized) {
            status.text = if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                "Mikrofon engedélyezve. Készen áll."
            else "A mikrofonengedély nélkül a beszédfelismerés nem használható."
        }
    }

    override fun onDestroy() {
        stopContinuousMode()
        closeTranslator()
        languageIdentifier?.close()
        languageIdentifier = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }
}

# Saját Magyar Tolmács – Android-prototípus 0.6.0

Ez egy Android Studio-ban megnyitható fejlesztői projekt. **Nem előre lefordított APK.**

## A 0.3.0 prototípusban
- Német → magyar és magyar → német fordítás.
- Beszédfelismerés a kiválasztott bemeneti nyelven.
- Kézzel beírt szöveg fordítása mikrofon nélkül is.
- ML Kit német–magyar szövegfordítás.
- Külön gomb a kiválasztott irány nyelvi modelljének letöltésére; letöltés után a szövegfordítás offline is működhet.
- A fordítás automatikus felolvasása és külön felolvasó gomb.
- A telefon aktuális hangkimenetének használata (pl. Bluetooth- vagy vezetékes headset, ha az Android oda irányítja a hangot).
- Legutóbbi 30 fordítás helyi mentése és előzménylista, törlési lehetőséggel.
- Irányváltó gomb és mikrofonengedély kezelése.
- A legutóbb kiválasztott fordítási irány megjegyzése.

## Korlátok – fontos
- Ez még nem folyamatos, valós idejű tolmács: minden megszólalás után külön kell elindítani a mikrofont.
- A beszédfelismerés offline működése a telefonra telepített beszédfelismerő szolgáltatástól és a letöltött nyelvi csomagoktól függ. Az offline mód kérése nem garancia.
- A fordítási modellek első letöltéséhez internetkapcsolat szükséges.
- A TTS hangok elérhetősége a telefonra telepített beszédmotoroktól és nyelvektől függ.
- A képernyőzár melletti háttérműködés, automatikus nyelvfelismerés és a különböző headsetek tényleges tesztelése még nincs kész.
- A projekt forráskódja nem helyettesíti a lefordított APK-t. APK még nincs lefordítva vagy eszközön tesztelve.

## 0.4.0 változásai
- A főképernyőn egy gombbal letölthető mindkét fordítási irány offline szövegfordító modellje; a letöltés egymás után történik, hibajelzéssel.
- A kiválasztott nyelvi irány újraindítás után is megmarad.

## APK készítése
1. Telepítsd az Android Studio-t egy számítógépre.
2. Csomagold ki a ZIP-et, majd Android Studio-ban nyisd meg a `SajatMagyarTolmacs` mappát.
3. Várd meg a Gradle szinkronizálást; internetkapcsolat szükséges az Android Gradle Plugin és az ML Kit függőség letöltéséhez.
4. Válaszd: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Az elkészült APK-t telepítsd a telefonra, és engedélyezd a mikrofon használatát.

A projekt Android 6.0+ rendszert céloz meg, ezért a Samsung Galaxy A70 Android 11 rendszerével kompatibilisnek készült, de tényleges készülékteszt még szükséges.


## 0.5.0 változásai
- A korábbi egyirányú modellletöltés helyett most egyetlen gomb letölti a német→magyar és a magyar→német modellt is.
- A letöltés állapotát külön jelzi, és hiba esetén felszabadítja a fordító erőforrásait.
- Ez továbbra sem teszi offline-ná automatikusan a telefon beszédfelismerőjét: az külön a készülék beszédfelismerő szolgáltatásától függ.


## 0.6.0 változásai
- Kísérleti folyamatos beszélgetés mód: a felismerés után lefordítja a mondatot, felolvassa, majd újra figyel.
- A folyamatos mód külön gombbal indítható és leállítható.
- A folyamatos mód az Android beszédfelismerő szolgáltatását használja; az offline működés nem garantált, a szolgáltató és a letöltött nyelvi csomagok függvénye.
- Ez váltott megszólalásos prototípus, nem teljes duplex, valós idejű tolmács. A fordítás és a felolvasás között rövid szünet lehet.
- A forráskódot ebben a környezetben nem tudtam Android SDK/Gradle segítségével lefordítani; APK és készülékteszt továbbra sincs.


## 0.7.0 változásai
- A folyamatos beszélgetés mód most a felolvasás befejezését várja meg, és csak utána indítja újra a beszédfelismerést. Ez csökkentheti annak esélyét, hogy a mikrofon a telefon saját felolvasását is felismerje.
- Felolvasási hiba vagy még nem kész beszédmotor esetén biztonsági újrapróbálkozás van.
- Verziószám: 0.7.0 (versionCode 7).
- Ez továbbra is kísérleti, váltott megszólalásos mód. A képernyő kikapcsolása melletti működés, a háttérszolgáltatás, az automatikus nyelvfelismerés és a készülékes/headsetes tesztelés nincs kész.
- Android SDK/Gradle ebben a munkakörnyezetben nem érhető el, ezért APK-t nem tudtam lefordítani vagy futtatni.


## 0.8.0 – automatikus nyelvfelismerés
- Hozzáadva az eszközön futó ML Kit nyelvazonosítás.
- A beírt vagy beszédfelismerő által visszaadott szövegnél német (`de`) és magyar (`hu`) nyelv esetén automatikusan beállítja a fordítás irányát.
- Az automatikus felismerés alapértelmezetten bekapcsolt, de a képernyőn kikapcsolható.
- Ha a nyelv nem azonosítható, vagy a felismerés hibázik, a kézzel kiválasztott irányt használja.
- Fontos: a beszédfelismerő bemeneti nyelvét továbbra is a kiválasztott irány határozza meg. Ez nem biztosít automatikus, két nyelv közötti mikrofonos váltást a folyamatos beszélgetésben.
- A nyelvazonosító modell be van csomagolva az alkalmazásba; ez növeli az APK méretét, de nem igényel külön nyelvmodell-letöltést.
- A 0.8.0 forráskód még nincs Androidon lefordítva vagy telefonon tesztelve.


## 0.8.1 – GitHub Actions APK-fordítás
- Hozzáadva egy GitHub Actions munkafolyamat, amely Java 17 és Gradle 8.7 használatával debug APK-t fordít.
- Sikeres fordítás esetén az APK GitHub Artifactként letölthető.
- A telefonról történő beállítás részletes lépései a `GITHUB_APK_UTMUTATO_HU.txt` fájlban vannak.
- A munkafolyamat és a beállítás még nincs a felhasználó GitHub-fiókjában lefuttatva; tényleges APK jelenleg továbbra sincs.
- Verziószám: 0.8.1 (versionCode 9).
